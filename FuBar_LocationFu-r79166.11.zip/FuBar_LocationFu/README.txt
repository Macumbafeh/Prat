FuBar - LocationFu v1.1 $Revision: 26538 $

Author: ckknight (ckknight@gmail.com)
$Date: 2007-01-29 18:43:00 -0500 (Mon, 29 Jan 2007) $

Keeps track of your current location.

TO INSTALL: Put the FuBar_LocationFu folder into
	\World of Warcraft\Interface\AddOns\

If you find _any_ bugs, feel free to submit them at
http://ckknight.wowinterface.com/portal.php?id=54&a=listbugs

If you want to request any features, feel free to submit your ideas at
http://ckknight.wowinterface.com/portal.php?id=54&a=listfeatures
